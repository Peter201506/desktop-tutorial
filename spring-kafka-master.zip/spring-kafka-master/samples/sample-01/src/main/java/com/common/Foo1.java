/*
 * Copyright 2018-2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.common;

import java.util.*;

/**
 * @author Gary Russell
 * @since 2.2.1
 *
 */
public class Foo1 implements Cloneable{

	private String foo;

	private String name;
	private int id;

	Look look;

	public Foo1() {
	}

	private void sortUsingJava8(List<String> names){
		Collections.sort(names, (s1, s2) -> s1.compareTo(s2));
	}

	public Foo1(String foo) {
		this.foo = foo;
	}

	public String getFoo() {
		return this.foo;
	}

	public void setFoo(String foo) {
		this.foo = foo;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Foo1)) return false;
		Foo1 foo1 = (Foo1) o;
		return id == foo1.id &&
				foo.equals(foo1.foo) &&
				name.equals(foo1.name);
	}

	@Override
	public int hashCode() {
		return Objects.hash(foo, name, id) + name.hashCode();
	}

	@Override
	public String toString() {
		return "Foo1 [foo=" + this.foo + "]";
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}

class Look{
	int id;
	String name;

}


