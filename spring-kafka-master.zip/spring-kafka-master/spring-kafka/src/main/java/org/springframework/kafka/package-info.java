/**
 * Base package for kafka
 */
package org.springframework.kafka;
