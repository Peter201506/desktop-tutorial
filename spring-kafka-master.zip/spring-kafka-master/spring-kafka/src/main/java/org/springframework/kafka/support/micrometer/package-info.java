/**
 * Provides classes to support Micrometer.
 */
package org.springframework.kafka.support.micrometer;
