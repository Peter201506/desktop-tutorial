/**
 * Package for kafka configuration
 */
package org.springframework.kafka.config;
